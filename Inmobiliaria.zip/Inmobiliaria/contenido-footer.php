Inmobiliaria Web - Desarrollado por Código Web <br>
<?php echo $config['telefono1'] . " - " . $config['email_contacto'] ?>